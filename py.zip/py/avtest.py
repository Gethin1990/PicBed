#%%
from PIL import Image
import cv2
from numpy import imag

file = 'D:\\Downloads\\3814.flv'
videoCap = cv2.VideoCapture(file)

for _i in range(1200):
    success, frame = videoCap.read()

img = Image.fromarray(frame)
img.show()

im = frame[:, :, 0]
im = im[130:260, :]
img = Image.fromarray(im)
img.show()

# %%
